"""Utilitaires PCM du moteur T1/T2 ; pas de téléchargement de musique."""

from pathlib import Path as P
import sys, os, re, json, hashlib, tempfile, subprocess, math
import numpy as np

D = P(__file__).resolve().parent
R = 48000
F = os.environ.get("FFMPEG", "ffmpeg")
H = lambda p: hashlib.sha256(P(p).read_bytes()).hexdigest()
I = lambda p: json.loads(P(p).read_text())
run = lambda a, **kw: subprocess.run(a, check=True, **kw)


def decode(p):
    return np.frombuffer(
        subprocess.check_output(
            [
                F,
                "-v",
                "error",
                "-i",
                str(p),
                "-map",
                "0:a:0",
                "-ar",
                str(R),
                "-ac",
                "2",
                "-f",
                "f32le",
                "-",
            ]
        ),
        "<f4",
    ).reshape(-1, 2)


def level(x):
    s = run(
        [
            F,
            "-hide_banner",
            "-nostats",
            "-f",
            "f32le",
            "-ar",
            str(R),
            "-ac",
            "2",
            "-i",
            "-",
            "-af",
            "loudnorm=print_format=json",
            "-f",
            "null",
            "-",
        ],
        input=np.asarray(x, "<f4").tobytes(),
        capture_output=True,
    ).stderr.decode()
    j = json.loads(re.findall(r"\{[^{}]+\}", s)[-1])
    return float(j["input_i"]), float(j["input_tp"])


def db(x):
    return 10 ** (x / 20)


def vh(p):
    return (
        subprocess.check_output(
            [
                F,
                "-v",
                "error",
                "-i",
                str(p),
                "-map",
                "0:v",
                "-c",
                "copy",
                "-f",
                "hash",
                "-hash",
                "sha256",
                "-",
            ]
        )
        .decode()
        .strip()
    )


def marchand(master, clips, scenes, profile, music, credit, target):
    cfg = profile["mix"]
    v = np.zeros((30 * R, 2), np.float32)
    audibles = []
    for p, sc in zip(clips, scenes):
        present = subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "a:0",
                "-show_entries",
                "stream=index",
                "-of",
                "csv=p=0",
                str(p),
            ]
        ).strip()
        if present:
            start, end = (sc[key] * R // 30 for key in ("debut", "fin_exclue"))
            a = decode(p)[: end - start]
            v[start : start + len(a)] = a
            if len(a) and abs(a).max() > 0.005:
                audibles.append(sc["id"])
    if audibles:
        li, tp = level(v)
        v *= db(min(-18.7 - li, -3 - tp))
    tt = np.arange(len(v)) / R
    env = np.zeros(len(v))
    active = np.sqrt((v.reshape(-1, 480, 2) ** 2).mean(axis=(1, 2))) > 0.005
    idx = np.flatnonzero(active)
    attack = cfg["attaque_ms"] / 1000
    release = cfg["relachement_ms"] / 1000
    for rg in np.split(idx, np.flatnonzero(np.diff(idx) > 48) + 1):
        if len(rg):
            env = np.maximum(
                env,
                np.minimum(
                    np.clip((tt - rg[0] / 100 + attack) / attack, 0, 1),
                    np.clip(((rg[-1] + 1) / 100 + release - tt) / release, 0, 1),
                ),
            )
    m = decode(music)[: len(v)].copy()
    assert m.shape == v.shape
    m *= db(-18 - level(m)[0])
    m *= db((cfg["fond_db"] + (cfg["sous_parole_db"] - cfg["fond_db"]) * env)[:, None])
    sel = np.repeat(active, 480)
    if np.any(sel):
        m *= db(
            min(
                0,
                10 * np.log10(np.mean(v[sel] ** 2) / max(1e-12, np.mean(m[sel] ** 2)))
                - 6,
            )
        )
    x = v + m
    x *= db(cfg["lufs"] - level(x)[0])
    x = np.clip(x, -db(-2.6), db(-2.6))
    run(
        [
            F,
            "-v",
            "error",
            "-y",
            "-i",
            str(master),
            "-f",
            "f32le",
            "-ar",
            str(R),
            "-ac",
            "2",
            "-i",
            "-",
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-metadata",
            "comment=" + credit,
            "-movflags",
            "+faststart",
            str(target),
        ],
        input=np.asarray(x, "<f4").tobytes(),
    )
    a = decode(target)
    li, tp = level(a)
    assert (
        vh(master) == vh(target)
        and abs(len(a) / R - 30) < 0.04
        and abs(li - cfg["lufs"]) < 1
        and tp < -0.8
    ), (li, tp)
    return dict(scenes_audio=audibles, lufs=li, true_peak_dbtp=tp)
